#!/usr/bin/env python3

import os
import shutil

R = '\033[31m' # red
G = '\033[32m' # green
C = '\033[36m' # cyan
W = '\033[0m'  # white

name = input(G + '[+]' + C + ' Name : ' + W)
username = input(G + '[+]' + C + ' UserName: ' + W)

with open('template/snap/index_temp.html', 'r') as index_temp:
    code = index_temp.read()
    code = code.replace('$NAME$', name)
    code = code.replace('$USERNAME$', username)

with open('template/snap/index.html', 'w') as new_index:
    new_index.write(code)